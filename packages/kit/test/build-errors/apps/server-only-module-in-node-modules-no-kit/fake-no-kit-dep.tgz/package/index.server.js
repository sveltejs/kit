export const should_not_explode = 'no boom';
