---
'@sveltejs/kit': patch
---

Prevent caching of `__data.js` files
