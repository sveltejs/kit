---
'create-svelte': patch
'@sveltejs/kit': patch
---

Add sync CLI command
