---
'@sveltejs/kit': patch
---

[fix] use defaults when no opts passed to router
