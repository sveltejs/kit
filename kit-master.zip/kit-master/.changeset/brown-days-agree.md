---
'@sveltejs/kit': patch
---

switch to @sveltejs/vite-plugin-svelte
