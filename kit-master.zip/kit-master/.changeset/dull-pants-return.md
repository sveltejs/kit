---
"@sveltejs/kit": patch
---

Build server without removing `sveltekit` Vite plugin
