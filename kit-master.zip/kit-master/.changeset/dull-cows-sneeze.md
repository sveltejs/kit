---
'@sveltejs/adapter-cloudflare': patch
'@sveltejs/adapter-cloudflare-workers': patch
---

Include ambient.d.ts files in adapter packages.
