---
'@sveltejs/kit': patch
---

Custom `load` `dependencies` in `LoadOutput`
