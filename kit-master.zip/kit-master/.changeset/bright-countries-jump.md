---
'@sveltejs/adapter-netlify': patch
---

Drop CJS version of adapter-netlify
