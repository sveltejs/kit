---
"@sveltejs/kit": patch
---

fix `write_types` on windows using posixify()
