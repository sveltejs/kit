---
'@sveltejs/kit': patch
---

[fix] `svelte-kit sync` gracefully handles a nonexistent routes folder
