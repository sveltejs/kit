---
'create-svelte': patch
---

Trying something
