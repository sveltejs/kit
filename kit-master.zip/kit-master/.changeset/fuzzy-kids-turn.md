---
'@sveltejs/kit': patch
---

Use UTF-8 encoding for JSON endpoint responses by default
