---
'@sveltejs/kit': patch
---

[fix] revert change to rendering options (#2008)
