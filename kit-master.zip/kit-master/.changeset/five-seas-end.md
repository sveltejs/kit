---
'@sveltejs/kit': patch
---

[fix] address Vite warning when using base or asset path
