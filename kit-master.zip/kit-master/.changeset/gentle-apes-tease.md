---
'@sveltejs/kit': patch
---

Prevent duplicated history when navigating via hash link
