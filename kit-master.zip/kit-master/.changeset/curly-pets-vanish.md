---
'@sveltejs/kit': patch
---

Handle requests for /basepath
