---
'@sveltejs/kit': patch
---

[fix] support undici 5.12.0 and pin it
