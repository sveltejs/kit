---
'@sveltejs/kit': patch
---

skip closeBundle hook during dev to prevent errors on restart
