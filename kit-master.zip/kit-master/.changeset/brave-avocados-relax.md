---
'@sveltejs/kit': patch
---

Skip pre-bundling
