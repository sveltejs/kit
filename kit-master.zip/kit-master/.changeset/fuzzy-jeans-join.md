---
'@sveltejs/adapter-node': patch
---

Make adapter node work under esm
