---
'@sveltejs/kit': patch
---

[fix] Set `errors` prop on all layout/leaf components, not just page that happens to be deepest
