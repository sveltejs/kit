---
'@sveltejs/kit': patch
---

Allow the `transformPage` resolve option to return a promise
