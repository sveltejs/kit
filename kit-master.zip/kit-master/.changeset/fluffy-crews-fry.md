---
'svelte-migrate': patch
---

Migrate type comments on arrow functions
