---
"@sveltejs/kit": patch
---

[fix] fallback should still be generated when prerender is disabled
