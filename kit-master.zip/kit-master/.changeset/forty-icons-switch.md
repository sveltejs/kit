---
'@sveltejs/kit': patch
---

Roll over non-matching optional parameters instead of 404ing
