---
'@sveltejs/kit': patch
---

Preserve explicit ETag header
