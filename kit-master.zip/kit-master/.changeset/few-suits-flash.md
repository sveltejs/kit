---
'@sveltejs/adapter-node': patch
---

Check if '[out]/prerendered' exists, before precompressing
