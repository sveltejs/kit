---
'@sveltejs/kit': patch
---

Fix fetch type
