---
'@sveltejs/adapter-node': patch
'@sveltejs/adapter-static': patch
'@sveltejs/kit': patch
---

Move `compress` logic to `Builder` API
