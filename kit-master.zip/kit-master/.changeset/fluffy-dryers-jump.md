---
'@sveltejs/kit': patch
---

Prevent ...rest parameters from swallowing earlier characters
