---
'@sveltejs/kit': patch
---

Add support for linking to <a name="hash"> tags
