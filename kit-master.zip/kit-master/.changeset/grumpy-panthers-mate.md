---
'@sveltejs/kit': patch
---

[fix] ignore hash links during prerendering (again)
