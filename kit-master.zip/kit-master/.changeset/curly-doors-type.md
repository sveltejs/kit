---
"create-svelte": patch
---

correct default package.json format
