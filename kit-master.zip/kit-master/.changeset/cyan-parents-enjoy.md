---
'create-svelte': patch
---

Simplify component file names
