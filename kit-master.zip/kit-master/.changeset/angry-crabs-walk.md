---
'@sveltejs/kit': patch
---

[breaking] require Node 16.9
