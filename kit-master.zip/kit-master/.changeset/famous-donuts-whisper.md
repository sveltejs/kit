---
'@sveltejs/kit': patch
---

make html template optional for `svelte-kit package`
