---
'create-svelte': patch
---

Add a programmatic interface to create-svelte
