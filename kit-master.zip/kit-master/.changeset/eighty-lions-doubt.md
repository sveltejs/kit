---
'@sveltejs/kit': patch
---

[feat] allow handleError to return a promise
