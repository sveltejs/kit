---
'@sveltejs/adapter-node': patch
'@sveltejs/kit': patch
---

[fix] handle paths consistently between dev and various production adapters
