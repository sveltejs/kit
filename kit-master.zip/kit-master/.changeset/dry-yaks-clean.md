---
'@sveltejs/kit': patch
---

Fix prerendering when paths.base but not paths.assets is specified
