---
'@sveltejs/adapter-cloudflare-workers': patch
---

Add config option to set custom `wrangler.toml` file name
