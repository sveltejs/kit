---
'@sveltejs/kit': patch
---

Accumulate data from parent layouts into `export let data`
