---
'@sveltejs/kit': patch
---

[fix] type tweaks
