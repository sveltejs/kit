---
'create-svelte': patch
---

Update version of eslint-plugin-svelte3
