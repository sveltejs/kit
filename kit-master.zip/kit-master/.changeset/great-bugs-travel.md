---
'@sveltejs/kit': patch
---

fix: SSL for HMR websockets #844
