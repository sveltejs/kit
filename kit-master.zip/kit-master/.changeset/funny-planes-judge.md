---
'@sveltejs/kit': patch
---

[fix] handle locked readable stream when reading body
