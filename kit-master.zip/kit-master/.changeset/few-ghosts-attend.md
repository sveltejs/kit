---
'@sveltejs/kit': patch
---

[breaking] catch and render raw response when unexpected error occurs in endpoint
