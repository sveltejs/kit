---
'@sveltejs/kit': patch
---

[breaking] more consistent casing for goto options
