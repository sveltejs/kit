---
'@sveltejs/kit': patch
---

[fix] reuse server data while not reusing client load
