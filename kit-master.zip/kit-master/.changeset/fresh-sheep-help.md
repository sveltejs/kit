---
'@sveltejs/kit': patch
---

[chore] return config from server start methods
