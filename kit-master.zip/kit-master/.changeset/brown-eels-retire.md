---
'@sveltejs/adapter-vercel': patch
---

[fix] don't fail on unknown error message
