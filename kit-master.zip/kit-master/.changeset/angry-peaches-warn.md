---
'@sveltejs/kit': patch
---

Hydration validation errors
