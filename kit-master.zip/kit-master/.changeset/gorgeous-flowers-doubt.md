---
'@sveltejs/kit': patch
---

[fix] silence prop warnings
