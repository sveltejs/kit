---
'@sveltejs/kit': patch
---

[breaking] Overhaul filesystem-based router (https://github.com/sveltejs/kit/discussions/5774)
