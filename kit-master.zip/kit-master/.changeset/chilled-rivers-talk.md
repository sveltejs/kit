---
'@sveltejs/kit': patch
---

Rename JSONString type to JSONValue
