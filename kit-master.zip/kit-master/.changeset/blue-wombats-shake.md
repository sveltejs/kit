---
'@sveltejs/adapter-static': patch
---

[docs] more specific error message when prerendering fails
