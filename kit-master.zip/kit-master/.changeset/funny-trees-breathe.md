---
'@sveltejs/kit': patch
---

Fix hash change focus behaviour
