---
'@sveltejs/kit': patch
---

[chore] Prerendering URL is now a subclass instead of a proxy
