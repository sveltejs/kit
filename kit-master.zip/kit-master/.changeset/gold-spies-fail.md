---
'@sveltejs/kit': patch
---

[fix] Windows correctly errors on `$env/*/private` imports
[fix] Illegal module analysis in dev ignores non-js|ts|svelte files
