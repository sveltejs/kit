---
'@sveltejs/kit': patch
---

[chore] upgrade Vite
