---
'@sveltejs/kit': patch
---

Disable meta http-equiv tags for static amp configuration
