---
'create-svelte': patch
---

Use the name of folder as name in package.json
