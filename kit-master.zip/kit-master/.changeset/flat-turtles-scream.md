---
'create-svelte': patch
'@sveltejs/kit': patch
---

Rename .svelte to .svelte-kit
