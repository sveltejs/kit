---
'@sveltejs/kit': patch
---

Fix preview when `kit.paths.base` is set.
