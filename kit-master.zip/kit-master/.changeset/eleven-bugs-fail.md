---
"create-svelte": patch
---

[fix] provide valid value for `letter-spacing` CSS property
