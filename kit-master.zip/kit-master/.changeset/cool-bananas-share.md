---
'@sveltejs/adapter-netlify': patch
---

Avoid setting the body of the request when the request method is GET or HEAD
