---
'@sveltejs/kit': patch
---

Replace function properties by methods on type declarations
