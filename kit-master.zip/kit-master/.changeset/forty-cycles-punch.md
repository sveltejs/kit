---
'@sveltejs/kit': patch
---

Add `transformPage` option to `resolve`
