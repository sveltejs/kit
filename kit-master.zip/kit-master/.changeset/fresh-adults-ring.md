---
'@sveltejs/kit': patch
---

Allow service workers to access files using the $lib alias
