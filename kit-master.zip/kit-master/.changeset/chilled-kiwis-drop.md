---
'@sveltejs/adapter-node': patch
---

Fix regression caused by writing `env.js` to the wrong path
