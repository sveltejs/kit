---
'@sveltejs/kit': patch
---

Return dependencies from render
