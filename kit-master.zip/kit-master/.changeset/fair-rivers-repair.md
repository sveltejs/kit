---
"@sveltejs/adapter-node": patch
---

Allow streaming when `BODY_SIZE_LIMIT` is set
