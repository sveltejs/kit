---
'@sveltejs/kit': patch
---

[breaking] narrow down possible status codes for redirects to 300-308
