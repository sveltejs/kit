---
'@sveltejs/kit': patch
---

prevent duplicate module ids by disabling optimizeDeps for @sveltejs/kit
