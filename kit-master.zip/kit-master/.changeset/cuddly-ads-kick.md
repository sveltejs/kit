---
'svelte-migrate': patch
---

handle more import cases
