---
'@sveltejs/kit': patch
---

[fix] enable Vite pre-bundling except for Svelte packages
