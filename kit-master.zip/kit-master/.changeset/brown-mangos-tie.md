---
'@sveltejs/kit': patch
---

[fix] refactor navigation singletons to avoid storing undefined reference
