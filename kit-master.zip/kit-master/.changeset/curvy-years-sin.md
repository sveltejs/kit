---
'@sveltejs/kit': patch
---

[fix] caching takes now into account the body payload
