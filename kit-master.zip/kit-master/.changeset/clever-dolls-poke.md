---
'@sveltejs/kit': patch
---

Indicate which request failed, if fetch fails inside load function
