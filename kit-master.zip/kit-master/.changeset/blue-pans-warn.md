---
'@sveltejs/kit': patch
---

[fix] vite dev no longer covers errors
