---
'@sveltejs/adapter-vercel': patch
---

Handle redirects inside SvelteKit
