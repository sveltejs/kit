---
'@sveltejs/kit': patch
---

[fix] successfully handle client errors
