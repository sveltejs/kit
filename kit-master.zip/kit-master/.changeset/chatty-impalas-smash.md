---
'@sveltejs/kit': patch
---

handle HEAD requests in endpoints
