---
'@sveltejs/kit': patch
---

[fix] ActionData type
