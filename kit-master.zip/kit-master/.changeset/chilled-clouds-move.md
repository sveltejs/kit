---
'svelte-migrate': patch
---

[feat] do uppercase http verbs migration on the fly
