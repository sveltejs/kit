---
'@sveltejs/kit': patch
---

[fix] better type generation for load functions with different return values
