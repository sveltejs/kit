---
'@sveltejs/kit': patch
---

Make touchstart listener passive
