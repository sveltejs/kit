---
"create-svelte": patch
---

[fix] update docs URL for App namespace interfaces
