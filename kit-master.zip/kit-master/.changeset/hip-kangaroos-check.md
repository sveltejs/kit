---
'@sveltejs/adapter-cloudflare-workers': patch
---

Simplify example wrangler.toml, and fix outdated README
