---
"@sveltejs/adapter-static": patch
---

fix error message
