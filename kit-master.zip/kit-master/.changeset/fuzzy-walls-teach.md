---
'@sveltejs/adapter-node': patch
---

[fix] take into account deep exports for external packages
