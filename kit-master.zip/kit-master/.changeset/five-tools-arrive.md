---
"@sveltejs/adapter-node": patch
"@sveltejs/adapter-vercel": patch
"@sveltejs/kit": patch
---

Redact error message if `getRequest` fails
