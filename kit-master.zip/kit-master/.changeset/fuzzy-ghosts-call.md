---
'create-svelte': patch
'@sveltejs/kit': patch
---

Move options behind kit namespace, change paths -> kit.files
