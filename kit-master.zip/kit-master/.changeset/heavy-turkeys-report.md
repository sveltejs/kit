---
'@sveltejs/kit': patch
---

fix returning null from endpoints
