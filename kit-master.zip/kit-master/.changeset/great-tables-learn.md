---
'@sveltejs/kit': patch
---

Run `svelte-kit sync` in all workspace directories during postinstall
