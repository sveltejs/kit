---
'@sveltejs/kit': patch
---

Use addEventListener instead of onload
