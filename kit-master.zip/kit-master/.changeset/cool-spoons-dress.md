---
'@sveltejs/kit': patch
---

Make --open option work with --https
