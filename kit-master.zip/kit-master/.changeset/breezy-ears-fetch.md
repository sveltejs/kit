---
"@sveltejs/kit": patch
---

fix error message for invalid request object
