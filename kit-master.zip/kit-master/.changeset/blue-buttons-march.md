---
"@sveltejs/kit": patch
---

[breaking] prevent import of `$lib/server` modules in client-facing code
