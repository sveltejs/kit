---
'@sveltejs/kit': patch
---

[fix] improve type of `init`
