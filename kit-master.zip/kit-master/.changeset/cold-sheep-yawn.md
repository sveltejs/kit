---
'@sveltejs/kit': patch
---

[breaking] remove kit.browser.hydrate config in favor of compilerOptions.hydratable
