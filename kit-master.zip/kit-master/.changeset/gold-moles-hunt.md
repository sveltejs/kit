---
'create-svelte': patch
---

add global.d.ts to js version
