---
'@sveltejs/kit': patch
---

Silence more unknown prop warnings coming from SvelteKit
