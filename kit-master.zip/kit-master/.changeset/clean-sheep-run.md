---
'@sveltejs/kit': patch
---

[feat] enable caching for `__data.json` requests
