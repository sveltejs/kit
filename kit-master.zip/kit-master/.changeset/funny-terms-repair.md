---
'@sveltejs/adapter-begin': patch
'@sveltejs/adapter-cloudflare-workers': patch
'@sveltejs/adapter-netlify': patch
'@sveltejs/adapter-node': patch
'@sveltejs/adapter-static': patch
'@sveltejs/adapter-vercel': patch
---

Remove peerDependencies due to pnpm bug
