---
'@sveltejs/kit': patch
---

[feat] allow using Vite's `strict.port: false` option
