---
'@sveltejs/kit': patch
---

[fix] correctly find links during prerendering
