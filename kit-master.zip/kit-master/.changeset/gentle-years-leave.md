---
'@sveltejs/kit': patch
---

Allow `$app/stores` to be used from anywhere on the browser
