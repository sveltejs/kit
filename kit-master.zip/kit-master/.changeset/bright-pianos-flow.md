---
'create-svelte': patch
---

Update app.d.ts files
