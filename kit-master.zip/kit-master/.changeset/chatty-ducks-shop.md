---
'@sveltejs/kit': patch
---

Prevent full reload when router navigates and only removes hash
