---
'@sveltejs/kit': patch
---

[breaking] Make `trailingSlash` a page option, rather than configuration
