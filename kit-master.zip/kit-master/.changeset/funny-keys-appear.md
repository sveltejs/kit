---
"@sveltejs/kit": patch
---

set errors on root component
