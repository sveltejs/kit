---
'create-svelte': patch
---

Replace /todos page in demo app with /sverdle
