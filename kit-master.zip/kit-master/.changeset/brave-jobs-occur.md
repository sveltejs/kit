---
'@sveltejs/kit': patch
---

feat: Pages marked for prerendering fail during ssr at runtime
