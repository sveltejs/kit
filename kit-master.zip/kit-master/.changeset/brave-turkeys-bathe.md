---
'@sveltejs/kit': patch
---

Allow first argument to fetch in load to be a request
