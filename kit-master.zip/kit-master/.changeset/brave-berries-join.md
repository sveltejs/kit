---
'@sveltejs/kit': patch
---

kit: include missing types.d.ts
