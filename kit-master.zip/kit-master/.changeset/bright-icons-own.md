---
'@sveltejs/kit': patch
---

Allow endpoints to return a Response, or an object with Headers
