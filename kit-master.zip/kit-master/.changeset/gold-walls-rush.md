---
'@sveltejs/kit': patch
---

Change illegal import message to reference public-facing code rather than client-side code
