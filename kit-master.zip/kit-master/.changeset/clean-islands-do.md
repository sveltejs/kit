---
'@sveltejs/kit': patch
---

[fix] remove private methods to make Safari 14.1 work
