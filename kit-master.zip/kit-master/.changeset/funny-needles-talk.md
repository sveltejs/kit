---
'@sveltejs/kit': patch
---

Only include CSS on an SSR'd page
