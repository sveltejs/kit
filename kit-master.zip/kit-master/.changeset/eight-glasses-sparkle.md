---
'@sveltejs/kit': patch
---

[fix] increase scroll debounce timeout
