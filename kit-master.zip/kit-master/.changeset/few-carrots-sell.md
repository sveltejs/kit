---
'@sveltejs/kit': patch
---

Populate fallback page when trailingSlash is "always"
