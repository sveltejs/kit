---
'@sveltejs/adapter-vercel': patch
---

Support for Node.js 16
