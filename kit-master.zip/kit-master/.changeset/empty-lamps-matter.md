---
'@sveltejs/kit': patch
---

[chore] upgrade Vite to 2.5.7
