---
'@sveltejs/kit': patch
---

Allow prerendered pages to link to non-prerenderable endpoints
