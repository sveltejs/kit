---
'@sveltejs/kit': patch
---

[fix] handle case where parent() refers to missing load function
