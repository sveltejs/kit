---
'@sveltejs/kit': patch
---

make HMR work outside localhost
