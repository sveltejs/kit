---
'@sveltejs/kit': patch
---

Expose version from `$app/environment`
