---
'@sveltejs/kit': patch
---

[fix] various `cookies` fixes and improvements
