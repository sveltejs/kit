---
'@sveltejs/adapter-cloudflare-workers': patch
---

Generate required package.json
