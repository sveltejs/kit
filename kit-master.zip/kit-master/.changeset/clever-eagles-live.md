---
'@sveltejs/adapter-node': patch
---

precompress assets and prerendered pages (html,js,json,css,svg,xml)
