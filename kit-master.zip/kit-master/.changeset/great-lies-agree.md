---
'@sveltejs/adapter-netlify': patch
---

Fix adapter-netlify edge functions
