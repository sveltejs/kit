---
'@sveltejs/kit': patch
---

Expose appDir to adapters
