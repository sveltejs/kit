---
'@sveltejs/kit': patch
---

Add public API to let adapters update .gitignore
