---
'@sveltejs/adapter-cloudflare-workers': patch
---

revert change to Cloudflare ES target version
