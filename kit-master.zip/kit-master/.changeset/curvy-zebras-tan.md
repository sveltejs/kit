---
'@sveltejs/kit': patch
---

Fix srcset parsing
