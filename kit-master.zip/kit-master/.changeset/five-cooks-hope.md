---
'@sveltejs/kit': patch
---

[feat] Support for `$env/dynamic/*` in Vite ecosystem tools
