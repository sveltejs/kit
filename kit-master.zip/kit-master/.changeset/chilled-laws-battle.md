---
'@sveltejs/kit': patch
---

Add hook to handle errors
