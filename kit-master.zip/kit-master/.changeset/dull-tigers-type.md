---
'@sveltejs/kit': patch
---

Fix typo causing misnamed assets folder
