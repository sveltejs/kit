---
'@sveltejs/kit': patch
---

Fix generated path extension for `AwaitedProperties`
