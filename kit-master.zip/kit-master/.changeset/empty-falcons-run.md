---
'@sveltejs/adapter-cloudflare': patch
---

Check for Cache match sooner; use `worktop` for types & Cache operations
