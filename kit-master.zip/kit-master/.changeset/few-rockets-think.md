---
'@sveltejs/vite-plugin-svelte': patch
---

Bump version to allow publishing via pnpm
