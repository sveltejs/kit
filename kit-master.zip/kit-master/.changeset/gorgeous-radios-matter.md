---
'@sveltejs/kit': patch
---

Allow FormData to be passed as RequestHandler type Body argument
