---
'@sveltejs/adapter-netlify': patch
---

Ensure tmp dir is created
