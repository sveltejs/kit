---
'@sveltejs/kit': patch
---

Allow absolute file paths given to package.dir
