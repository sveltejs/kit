---
'@sveltejs/adapter-vercel': patch
---

Revert to cjs mode when building for lambda
