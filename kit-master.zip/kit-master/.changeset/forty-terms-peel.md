---
'@sveltejs/kit': patch
---

Add config.kit.outDir
