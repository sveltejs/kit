---
'@sveltejs/kit': patch
---

Use shadow endpoint without defining a `get` endpoint
