---
'create-svelte': patch
---

Add button:focus CSS styles to index page of default app
