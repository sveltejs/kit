---
'@sveltejs/kit': patch
---

[fix] error components render with correct layout client-side as well as server-side
