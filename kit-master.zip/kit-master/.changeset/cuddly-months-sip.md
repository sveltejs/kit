---
"@sveltejs/kit": patch
---

Prevent infinite reloads on `/` when root `+layout.server.js` exports `load`
