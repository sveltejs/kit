---
'@sveltejs/adapter-auto': patch
'@sveltejs/adapter-cloudflare': patch
'@sveltejs/adapter-cloudflare-workers': patch
'@sveltejs/adapter-netlify': patch
'@sveltejs/adapter-node': patch
'@sveltejs/adapter-static': patch
'@sveltejs/adapter-vercel': patch
'@sveltejs/kit': patch
---

Overhaul adapter API
