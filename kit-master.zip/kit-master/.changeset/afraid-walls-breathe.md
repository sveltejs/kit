---
'create-svelte': patch
---

Fix template description for SvelteKit demo app
