---
'@sveltejs/adapter-node': patch
---

Add missing Rollup dependency
