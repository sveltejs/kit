---
'create-svelte': patch
---

Try this
