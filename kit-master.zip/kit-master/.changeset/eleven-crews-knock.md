---
'@sveltejs/kit': patch
---

Handle circular dependencies in dynamic imports
