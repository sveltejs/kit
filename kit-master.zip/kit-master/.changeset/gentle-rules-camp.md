---
'@sveltejs/kit': patch
---

Fix url pathname for prerenders
