---
'@sveltejs/kit': patch
---

Allow multiple different headers returned from one endpoint
