---
'@sveltejs/kit': patch
---

allow async function for `enhance` action parameter
