---
'@sveltejs/kit': patch
---

cookies.delete fix #6609
