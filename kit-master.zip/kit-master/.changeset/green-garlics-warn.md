---
'create-svelte': patch
---

Add option to create integration tests with Playwright
