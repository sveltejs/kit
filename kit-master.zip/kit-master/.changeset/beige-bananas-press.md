---
'@sveltejs/kit': patch
---

Prevent infinite loop when fetching bad URLs inside error responses
