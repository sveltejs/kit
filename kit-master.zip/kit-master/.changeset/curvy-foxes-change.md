---
'@sveltejs/kit': patch
---

[fix] don't redirect to external URLs when normalizing paths
