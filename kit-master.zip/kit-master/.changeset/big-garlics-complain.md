---
'@sveltejs/adapter-netlify': patch
---

Allow custom redirects for Netlify Adapter
