---
'@sveltejs/kit': patch
---

Add sveltekit:prefetch and sveltekit:noscroll
