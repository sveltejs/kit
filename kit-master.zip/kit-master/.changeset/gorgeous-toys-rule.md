---
"create-svelte": patch
---

bump eslint ecmaVersion to 2020
