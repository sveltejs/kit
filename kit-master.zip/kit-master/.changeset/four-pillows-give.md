---
'@sveltejs/kit': patch
---

Add svelte-kit package command
