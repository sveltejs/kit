---
'@sveltejs/kit': patch
---

Error if handle hook returns something other than a Response
