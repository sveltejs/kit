---
'@sveltejs/kit': patch
---

Allow Response object to be returned without properties showing up in object constructor
