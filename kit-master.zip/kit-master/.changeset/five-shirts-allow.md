---
'@sveltejs/kit': patch
---

let hash only changes be handled by router
