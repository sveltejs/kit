---
'@sveltejs/adapter-cloudflare': patch
'@sveltejs/adapter-cloudflare-workers': patch
---

[breaking] Don't pass arbitrary options to esbuild
