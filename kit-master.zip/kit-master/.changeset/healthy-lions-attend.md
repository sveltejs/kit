---
'@sveltejs/kit': patch
---

Added form property to \$page store
