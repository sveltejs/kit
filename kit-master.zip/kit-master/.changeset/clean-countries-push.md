---
'@sveltejs/kit': patch
---

Set `$page.url` to current URL in browser
