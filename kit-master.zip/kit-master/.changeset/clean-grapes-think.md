---
'create-svelte': patch
---

Ignore Vite timestamp files by default in `create-svelte` templates (added to `.gitignore`)
