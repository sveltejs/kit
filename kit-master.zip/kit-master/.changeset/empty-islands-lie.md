---
'@sveltejs/kit': patch
---

fix casing of `.DS_Store` in the default config for `serviceWorker`
