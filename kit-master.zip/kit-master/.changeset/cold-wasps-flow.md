---
'@sveltejs/kit': patch
---

Allow ActionData to be undefined
