---
'@sveltejs/adapter-cloudflare-workers': patch
---

Add es2020 target to esbuild function to solve Unexpected character '#' error
