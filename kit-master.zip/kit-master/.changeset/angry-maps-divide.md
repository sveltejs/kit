---
'@sveltejs/kit': patch
---

[fix] successfully load nested error pages
