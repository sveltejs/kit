---
'@sveltejs/kit': patch
---

Allow adapter.adapt to be synchronous
