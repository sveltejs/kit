---
'@sveltejs/adapter-auto': patch
'create-svelte': patch
'@sveltejs/kit': patch
---

fix links pointing to multi-page docs
