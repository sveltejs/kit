---
'@sveltejs/kit': patch
---

Prevent double-fixing of error stack traces in dev mode
