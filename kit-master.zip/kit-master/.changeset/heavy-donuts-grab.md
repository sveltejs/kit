---
'@sveltejs/kit': patch
---

Pass trailingSlash config to adapters
