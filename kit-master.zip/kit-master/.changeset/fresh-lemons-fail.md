---
'create-svelte': patch
---

Move `data-sveltekit-prefetch` to `<nav>` element
