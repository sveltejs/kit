---
'@sveltejs/adapter-node': patch
---

Handle Uint8Array bodies from endpoints
