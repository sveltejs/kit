---
'@sveltejs/kit': patch
---

Fix svelte-kit adapt for Windows
