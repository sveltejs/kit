---
'@sveltejs/kit': patch
---

handle undefined body on endpoint output
