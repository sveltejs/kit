---
'@sveltejs/kit': patch
---

[fix] adapt in closeBundle
