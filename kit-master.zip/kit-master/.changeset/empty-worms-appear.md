---
'@sveltejs/kit': patch
---

Don't register service worker if there is none
