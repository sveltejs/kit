---
'@sveltejs/kit': patch
---

Prevent Vite from copying static assets if directory is called "public"
