---
'@sveltejs/kit': patch
---

Add --https flag to dev and start
