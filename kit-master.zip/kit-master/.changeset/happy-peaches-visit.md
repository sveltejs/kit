---
'@sveltejs/kit': patch
---

Render pages without a .svelte file in their proper layout/error files
