---
'@sveltejs/kit': patch
---

Use rendered CSS for AMP pages
