---
'@sveltejs/adapter-cloudflare-workers': patch
---

Aligns request/response API of cloudflare-workers adapter with others
