---
'@sveltejs/kit': patch
---

fix handling an incoming request from HTTP/2
