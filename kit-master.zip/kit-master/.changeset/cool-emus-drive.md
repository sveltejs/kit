---
'@sveltejs/kit': patch
---

[breaking] use devalue to (de)serialize action data
