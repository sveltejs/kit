---
'@sveltejs/kit': patch
---

Added `server` and `prod` env variables
