---
'@sveltejs/kit': patch
---

remove FLoC protection, now that we vanquished Google
