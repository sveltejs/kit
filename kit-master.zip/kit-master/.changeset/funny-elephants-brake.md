---
'@sveltejs/kit': patch
---

[chore] Upgrade undici so that we can use its multipart form data parsing instead of node-fetch's
