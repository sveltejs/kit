---
'@sveltejs/kit': patch
---

Make `manifest.mimeTypes` part of the public API
