---
'@sveltejs/kit': patch
'create-svelte': patch
---

Add methodOverride option for submitting PUT/PATCH/DELETE/etc with <form> elements
