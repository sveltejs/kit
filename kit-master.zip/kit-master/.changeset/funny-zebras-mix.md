---
'@sveltejs/kit': patch
---

Throw on accessing url.search/searchParams from page store during prerendering
