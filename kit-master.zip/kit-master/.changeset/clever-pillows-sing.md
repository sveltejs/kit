---
'@sveltejs/kit': patch
---

[fix] match route against decoded path on client
