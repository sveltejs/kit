---
'@sveltejs/kit': patch
---

[breaking] require Vite 3.1.0-beta.1
