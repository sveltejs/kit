---
'@sveltejs/kit': patch
---

[chore] provide Vite config via plugin
