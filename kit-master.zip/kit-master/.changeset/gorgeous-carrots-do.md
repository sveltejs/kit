---
'@sveltejs/adapter-netlify': patch
---

Fix string replacement in CJS builds
