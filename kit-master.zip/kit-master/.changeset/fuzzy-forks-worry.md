---
'@sveltejs/kit': patch
---

Replace page.host with page.origin
