---
'@sveltejs/kit': patch
---

[breaking] prevent server-side fetch from reading files with # character in the filename
