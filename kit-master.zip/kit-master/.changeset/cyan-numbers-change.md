---
'@sveltejs/adapter-cloudflare': patch
---

Pass `env` object to SvelteKit via `platform`
