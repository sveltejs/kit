---
"@sveltejs/adapter-cloudflare": patch
---

[fix] return 404 instead of 200 for missing assets
