---
'@sveltejs/kit': patch
---

Focus on `body` instead of `html` on navigation due to issues on Firefox
