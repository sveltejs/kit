---
'create-svelte': patch
---

Use separate ignore files for prettier and eslint
