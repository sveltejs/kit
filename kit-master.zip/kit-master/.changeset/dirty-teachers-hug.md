---
'create-svelte': patch
---

Added the option to add Vitest to new projects
