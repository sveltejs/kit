---
'@sveltejs/kit': patch
---

Throw load validation errors so that they are caught by handleError
