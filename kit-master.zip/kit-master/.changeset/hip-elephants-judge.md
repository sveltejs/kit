---
'@sveltejs/kit': patch
---

Ensure router is initialized before parsing location
