---
'@sveltejs/adapter-vercel': patch
---

Support build output API, with edge functions and code-splitting
