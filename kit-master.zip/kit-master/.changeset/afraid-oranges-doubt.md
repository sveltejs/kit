---
'create-svelte': patch
---

Ignore .turbo directory when building templates
