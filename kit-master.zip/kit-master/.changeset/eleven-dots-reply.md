---
'@sveltejs/kit': patch
---

`svelte-kit package` errors when lib directory does not exist
