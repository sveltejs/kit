---
'create-svelte': patch
---

Add '\$service-worker' to paths in tsconfig.json
