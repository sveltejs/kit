---
'@sveltejs/kit': patch
---

Include CSS for entry point/generated component
