---
'@sveltejs/kit': patch
'create-svelte': patch
---

[breaking] Replace `data-sveltekit-prefetch` with `-preload-code` and `-preload-data`
