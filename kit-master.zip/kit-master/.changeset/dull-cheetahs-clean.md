---
'@sveltejs/kit': patch
---

[breaking] remove App.PrivateEnv and App.PublicEnv in favour of generated types
