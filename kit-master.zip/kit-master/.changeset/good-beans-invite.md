---
'@sveltejs/kit': patch
---

Run adapt via svelte-kit build
