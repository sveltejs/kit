---
"@sveltejs/kit": patch
---

chore(kit): correct `engines` constraint
