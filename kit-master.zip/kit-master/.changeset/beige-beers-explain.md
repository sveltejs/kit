---
'@sveltejs/adapter-node': patch
---

[fix] provide default port only if path not provided
