---
'@sveltejs/kit': patch
'@sveltejs/snowpack-config': patch
---

Upgrade to Snowpack 3
