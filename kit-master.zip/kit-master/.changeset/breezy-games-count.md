---
'@sveltejs/kit': patch
---

Escape prerendered redirect locations, instead of encoding them
