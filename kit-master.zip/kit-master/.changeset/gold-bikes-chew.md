---
'@sveltejs/kit': patch
---

[breaking] Replace `maxage` with `cache` in `LoadOutput`
