---
'@sveltejs/kit': patch
---

Add `Access-Control-Allow-Origin: *` to static assets in dev
