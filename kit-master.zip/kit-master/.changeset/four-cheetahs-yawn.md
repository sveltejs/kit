---
'@sveltejs/kit': patch
---

Pin vite-plugin-svelte version
