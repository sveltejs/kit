---
'@sveltejs/kit': patch
---

Use /\_svelte_kit_assets when serving apps with specified paths.assets locally
