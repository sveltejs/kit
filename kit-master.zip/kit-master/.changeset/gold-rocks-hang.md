---
'create-svelte': patch
---

update `app.d.ts` for library skeleton template
