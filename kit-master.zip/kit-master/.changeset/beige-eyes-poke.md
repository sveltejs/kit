---
'@sveltejs/kit': patch
---

Fix types reference in exports in package.json
