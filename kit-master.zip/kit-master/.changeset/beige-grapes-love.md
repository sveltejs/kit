---
'@sveltejs/kit': patch
---

Always apply layout props when hydrating
