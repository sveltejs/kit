---
'@sveltejs/kit': patch
---

[breaking] Remove session object
