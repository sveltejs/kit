---
'@sveltejs/kit': patch
---

allow any top-level keys in svelte config
