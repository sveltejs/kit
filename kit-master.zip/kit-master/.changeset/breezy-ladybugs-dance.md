---
'@sveltejs/kit': patch
---

[breaking] change Navigation type to include from/to.params and from/to.routeId
