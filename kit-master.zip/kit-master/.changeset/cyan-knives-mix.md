---
'@sveltejs/kit': patch
---

Fix escaping of URLs of endpoint responses serialized into SSR response
