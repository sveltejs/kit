---
'@sveltejs/kit': patch
---

Fix ReadOnlyFormData keys and values method implementation
