---
'@sveltejs/kit': patch
---

The return type of cookies.get is string|undefined #6865
