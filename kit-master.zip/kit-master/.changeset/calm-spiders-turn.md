---
'create-svelte': patch
---

make demo app work without JS
