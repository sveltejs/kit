---
'@sveltejs/adapter-cloudflare-workers': patch
---

Pass rawBody to SvelteKit, bundle worker with esbuild
