---
'@sveltejs/kit': patch
---

[fix] silence unused type hints in generated proxy files
