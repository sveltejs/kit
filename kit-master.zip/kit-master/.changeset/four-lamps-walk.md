---
'@sveltejs/kit': patch
---

[breaking] Disallow error status codes outside 400-599
