---
'@sveltejs/kit': patch
---

Don't automatically buffer request bodies
