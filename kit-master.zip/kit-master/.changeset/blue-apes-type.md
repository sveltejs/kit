---
'@sveltejs/kit': patch
---

Add service worker support
