---
"@sveltejs/kit": patch
---

fix: correctly detect removal of route
