---
'@sveltejs/kit': patch
---

Add `fetch` to `RequestEvent`
