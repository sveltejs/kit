---
'@sveltejs/kit': patch
---

Prevent Vite from nuking logs on startup
