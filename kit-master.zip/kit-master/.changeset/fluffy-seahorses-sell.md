---
'@sveltejs/kit': patch
---

Prevent component double mounting caused by HMR invalidation
