---
'@sveltejs/kit': patch
---

Expose Vite plugin as @sveltejs/kit/experimental/vite
