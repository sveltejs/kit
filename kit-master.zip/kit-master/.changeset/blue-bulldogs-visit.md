---
'@sveltejs/kit': patch
---

[fix] upgrade to Vite 2.5.2 to fix URL decoding
