---
'@sveltejs/kit': patch
---

app.js -> app.cjs
