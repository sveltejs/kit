---
'@sveltejs/kit': patch
---

[chore] prefer interfaces to types
