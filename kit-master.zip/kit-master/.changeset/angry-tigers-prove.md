---
'@sveltejs/kit': patch
---

Follow redirects when prerendering
