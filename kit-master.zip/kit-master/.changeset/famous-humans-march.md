---
'@sveltejs/adapter-netlify': patch
'@sveltejs/adapter-vercel': patch
'@sveltejs/kit': patch
---

Transfer server data as devalue-encoded JSON
