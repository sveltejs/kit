---
'@sveltejs/kit': patch
---

Serve prerendered non-page files when running preview
