---
'@sveltejs/kit': patch
---

[fix] avoid mutating response `Headers`
