---
'@sveltejs/kit': patch
---

load env before importing hooks during dev
