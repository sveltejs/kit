---
'@sveltejs/kit': patch
---

[breaking] change data-hydrate to data-sveltekit-hydrate
