---
'@sveltejs/adapter-vercel': patch
---

Print friendlier message if adapter-vercel fails to resolve dependencies
