---
'create-svelte': patch
---

Bump `eslint` from version 7 to 8
