---
'create-svelte': patch
---

Use aria-current instead of active class in nav
