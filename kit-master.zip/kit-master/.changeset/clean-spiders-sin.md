---
"create-svelte": patch
---

[fix] use inline element in heading
