---
'create-svelte': patch
---

Use next tag for all packages
