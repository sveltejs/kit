---
'@sveltejs/kit': patch
---

[breaking] rename prerender.pages config option to prerender.entries
