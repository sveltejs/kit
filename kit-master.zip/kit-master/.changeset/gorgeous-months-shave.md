---
'@sveltejs/kit': patch
---

[fix] forward cookie headers on etag response
