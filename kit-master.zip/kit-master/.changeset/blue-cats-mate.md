---
'@sveltejs/kit': patch
---

Force version bump so that Kit uses updated vite-plugin-svelte
