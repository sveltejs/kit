---
'@sveltejs/adapter-begin': patch
---

Use new app-utils format
