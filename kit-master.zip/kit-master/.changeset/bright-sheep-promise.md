---
'@sveltejs/adapter-cloudflare-workers': patch
'@sveltejs/adapter-netlify': patch
---

change toml parser to support dotted keys and other language features added after the TOML v0.4.0 spec
