---
'@sveltejs/kit': patch
---

Fixes `navigating` store type
