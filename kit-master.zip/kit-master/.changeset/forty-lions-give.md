---
'@sveltejs/kit': patch
---

[breaking] resolve relative urls from the target page when using load's fetch
