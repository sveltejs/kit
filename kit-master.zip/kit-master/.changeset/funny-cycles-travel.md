---
'@sveltejs/kit': patch
---

[fix] update current.url on hashchange
