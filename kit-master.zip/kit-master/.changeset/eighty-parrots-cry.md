---
'@sveltejs/kit': patch
---

[feat] provide `SubmitFunction` type
