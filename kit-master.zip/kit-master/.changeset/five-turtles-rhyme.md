---
'@sveltejs/kit': patch
---

[fix] correctly populate `event.url.host` in dev mode when using `--https`
