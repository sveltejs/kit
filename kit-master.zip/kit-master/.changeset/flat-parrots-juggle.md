---
'create-svelte': patch
---

Update welcome message
