---
'create-svelte': patch
'@sveltejs/kit': patch
---

Add \$lib alias
