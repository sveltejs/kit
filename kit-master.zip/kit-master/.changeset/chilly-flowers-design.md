---
'realworld.svelte.dev': patch
'sandbox': patch
'@sveltejs/kit': patch
---

Future-proof prepare argument
