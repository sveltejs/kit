---
'@sveltejs/adapter-cloudflare-workers': patch
'@sveltejs/adapter-netlify': patch
'@sveltejs/adapter-vercel': patch
---

Upgrade esbuild to ^0.12.5
