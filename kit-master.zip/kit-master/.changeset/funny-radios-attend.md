---
'@sveltejs/kit': patch
---

[fix] Prevent import of `$env/*/private` in client
