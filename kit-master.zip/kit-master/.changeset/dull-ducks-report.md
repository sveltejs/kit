---
'@sveltejs/kit': patch
---

[breaking] Use Vite defaults for port and strictPort
