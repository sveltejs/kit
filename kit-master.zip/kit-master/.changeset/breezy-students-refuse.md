---
'@sveltejs/kit': patch
---

Update vite-plugin-svelte to 1.0.0-next.22
