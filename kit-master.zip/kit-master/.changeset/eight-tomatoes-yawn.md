---
'@sveltejs/kit': patch
---

[fix] don't watch `outDir`, except for the `generated` directory
