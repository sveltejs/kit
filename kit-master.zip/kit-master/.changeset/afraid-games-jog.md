---
'@sveltejs/kit': patch
---

[fix] prerender routes in a (group)
