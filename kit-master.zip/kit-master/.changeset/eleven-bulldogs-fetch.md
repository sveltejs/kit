---
"@sveltejs/kit": patch
---

Pause Node streams as necessary when converting to ReadableStream
