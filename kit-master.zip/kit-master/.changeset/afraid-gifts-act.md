---
'@sveltejs/adapter-cloudflare': patch
'@sveltejs/kit': patch
---

Support Cloudflare Pages `_routes.json` specification
