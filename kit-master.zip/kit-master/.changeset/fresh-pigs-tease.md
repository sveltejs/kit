---
'@sveltejs/kit': patch
---

[breaking] remove ability for `+page.server.js` to respond to `GET` requests with JSON
