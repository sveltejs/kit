---
'@sveltejs/kit': patch
---

[breaking] referer header sent by fetch in load matches page's referer header, not the page itself
