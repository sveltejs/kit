---
'@sveltejs/kit': patch
---

The redirect property returned from a module's load function must now be a properly encoded URI string value.
