---
'@sveltejs/kit': patch
---

Allow symlinked directories in the routes folder
