---
'@sveltejs/kit': patch
---

Fail build if prerender errors
