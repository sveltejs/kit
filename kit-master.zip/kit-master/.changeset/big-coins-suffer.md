---
'@sveltejs/kit': patch
---

Check url protocol to avoid mailto links navigated by kit in mobile devices
