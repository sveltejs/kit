---
'@sveltejs/kit': patch
---

Breaking: Add disableScrollHandling function (see https://kit.svelte.dev/docs/modules#$app-navigation)
