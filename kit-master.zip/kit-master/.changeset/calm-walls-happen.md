---
'create-svelte': patch
---

Ensure template files match Prettier settings
