---
'@sveltejs/adapter-static': patch
'@sveltejs/kit': patch
---

[breaking] remove `createIndexFiles` option, derive from `trailingSlash` instead
