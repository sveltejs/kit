---
'@sveltejs/adapter-static': patch
---

add precompress option to adapter-static
