---
'@sveltejs/kit': patch
---

[breaking] change `config.kit.prerender.onError` to `handleHttpError`, and check for invalid fragment links
