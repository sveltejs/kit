---
'@sveltejs/kit': patch
---

Apply `data-sveltekit-prefetch/noscroll/reload` to all child `<a>` elements
