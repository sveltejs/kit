---
'create-svelte': patch
---

Add README
