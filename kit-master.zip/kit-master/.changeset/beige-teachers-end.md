---
'@sveltejs/kit': patch
---

Use global URLSearchParams instead of import from node url
