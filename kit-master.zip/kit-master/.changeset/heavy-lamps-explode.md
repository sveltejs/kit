---
'create-svelte': patch
---

Update tsconfig to use module and lib es2020
