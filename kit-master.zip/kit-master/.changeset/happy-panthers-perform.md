---
'@sveltejs/kit': patch
---

[fix] migration error when using $page.routeId
