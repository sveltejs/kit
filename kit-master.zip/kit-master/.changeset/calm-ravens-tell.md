---
'@sveltejs/kit': patch
---

[breaking] allow `InputProps` and `OutputProps` to be typed separately in generated `Load`
