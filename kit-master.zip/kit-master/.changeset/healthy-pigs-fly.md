---
'create-svelte': patch
---

Make hooks file comply with TypeScript strictest mode
