---
'@sveltejs/kit': patch
---

[chore] shared Vite build config
