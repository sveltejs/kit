---
'@sveltejs/kit': patch
---

[breaking] Replace timestamp in \$service-worker with version
