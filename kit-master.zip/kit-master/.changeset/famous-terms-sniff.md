---
'create-svelte': patch
'@sveltejs/kit': patch
---

Bump vite-plugin-svelte and required vite version
