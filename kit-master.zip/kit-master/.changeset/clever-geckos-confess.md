---
'@sveltejs/kit': patch
---

Set cookies when redirecting from shadow endpoint
