---
'@sveltejs/kit': patch
---

[breaking] throw error when routes conflict
