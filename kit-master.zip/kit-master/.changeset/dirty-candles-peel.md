---
'@sveltejs/kit': patch
---

[fix] allow missing routes folder
