---
'@sveltejs/adapter-netlify': patch
---

Prevent adapter from splitting query params if they contain commas
