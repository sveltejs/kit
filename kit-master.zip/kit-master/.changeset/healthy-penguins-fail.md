---
'create-svelte': patch
---

Create vite.config.ts when creating TypeScript project
