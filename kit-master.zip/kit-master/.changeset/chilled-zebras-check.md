---
'@sveltejs/kit': patch
---

Update compatible Node versions
