---
'@sveltejs/kit': patch
---

Only require page components to export prerender
