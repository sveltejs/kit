---
'@sveltejs/kit': patch
---

Bump Vite to 2.3.0
