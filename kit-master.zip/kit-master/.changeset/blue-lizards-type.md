---
'@sveltejs/kit': patch
---

[fix] prevent data types from becoming type `never`, notice moved/deleted files
