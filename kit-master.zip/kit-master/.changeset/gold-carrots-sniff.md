---
'@sveltejs/kit': patch
---

[fix] don't expose prerender options
