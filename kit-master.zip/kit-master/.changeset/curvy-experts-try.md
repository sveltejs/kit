---
'@sveltejs/kit': patch
---

Make shadow endpoint `event.url` consistent between server and client navigation
