---
'@sveltejs/kit': patch
---

Respect `config.kit.env.dir` when running `vite preview`
