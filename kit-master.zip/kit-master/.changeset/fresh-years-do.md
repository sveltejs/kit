---
'@sveltejs/kit': patch
---

Replace config.kit.hostHeader with config.kit.headers.host, add config.kit.headers.protocol
