---
'@sveltejs/kit': patch
---

Allow \_\_fetch_polyfill() to run several times
