---
'create-svelte': patch
---

Create TypeScript/JSDoc/vanilla versions of shared template .ts files
