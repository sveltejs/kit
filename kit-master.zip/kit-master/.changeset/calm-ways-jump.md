---
'@sveltejs/kit': patch
---

Don't hardcode version in client bundle
