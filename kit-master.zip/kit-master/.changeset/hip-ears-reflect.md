---
'@sveltejs/kit': patch
---

[breaking] add lib, module, and target to generated tsconfig
