---
'@sveltejs/adapter-static': patch
---

Make options object optional
