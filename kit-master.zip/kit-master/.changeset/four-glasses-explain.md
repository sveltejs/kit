---
'@sveltejs/kit': patch
---

[fix] allow user to set dev port
