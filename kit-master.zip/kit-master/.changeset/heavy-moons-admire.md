---
'@sveltejs/kit': patch
---

url hash is now properly reflected in page store
