---
'@sveltejs/kit': patch
---

[fix] handle jsdoc without tags while generating proxy types
