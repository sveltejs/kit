---
'@sveltejs/adapter-auto': patch
---

Attempt to bump @next version of adapter-auto
