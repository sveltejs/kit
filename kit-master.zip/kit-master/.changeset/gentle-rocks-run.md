---
'@sveltejs/package': patch
---

[feat] warn if svelte not found in dependencies or peerDependencies
