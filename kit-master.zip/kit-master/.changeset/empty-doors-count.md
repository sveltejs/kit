---
'@sveltejs/kit': patch
---

Disallow access to `__data.json` for standalone endpoints
