---
'@sveltejs/kit': patch
---

Fall back to full page reload if link href does not match route manifest
