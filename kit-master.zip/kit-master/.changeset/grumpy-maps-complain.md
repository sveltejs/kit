---
"@sveltejs/kit": patch
---

[breaking] remove `getStaticDirectory()` from builder API
