---
'@sveltejs/kit': patch
---

[fix] harmonize cookie path and add dev time warnings
