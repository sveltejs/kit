---
'@sveltejs/kit': patch
---

[fix] prevent double decoding of params
