---
'@sveltejs/kit': patch
---

Prevent `Host` header from being incorrectly inherited by requests made from `load`'s `fetch` during SSR
