---
'@sveltejs/kit': patch
---

create `__data.json` for pathnames with trailing slashes, including `/`
