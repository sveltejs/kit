---
'@sveltejs/kit': patch
---

add optional state parameter for goto function
