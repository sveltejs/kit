---
'@sveltejs/adapter-node': patch
---

Don't cache non-hashed static assets in adapter-node
