---
'@sveltejs/kit': patch
---

Fix XSS vulnerability on SSR pages with fetched data on `load()`
