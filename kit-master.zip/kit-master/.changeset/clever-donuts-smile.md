---
'@sveltejs/kit': patch
---

`svelte-kit package` gives clearer error message when svelte2tsx and typescript are not installed
