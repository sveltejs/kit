---
'@sveltejs/kit': patch
---

Support multiple rel values on anchor tag
