---
'@sveltejs/kit': patch
---

Move config.kit.hydrate and config.kit.router to config.kit.browser
