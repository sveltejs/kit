---
'create-svelte': patch
---

Remove initial-scale=1 from meta tags
