---
'@sveltejs/kit': patch
---

Enable multipart formdata parsing with node-fetch
