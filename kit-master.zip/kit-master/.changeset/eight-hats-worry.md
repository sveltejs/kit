---
'@sveltejs/adapter-node': patch
---

[fix] regression where builds not using `entryPoint` stopped having `middlewares.js` external
