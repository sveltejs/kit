---
"@sveltejs/kit": patch
---

[breaking] revert removal of `kit.browser.hydrate`
