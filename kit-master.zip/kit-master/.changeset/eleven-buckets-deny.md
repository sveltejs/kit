---
'@sveltejs/adapter-static': patch
---

[breaking] Throws when correctly configured to run as a static site of a SPA
