---
'@sveltejs/kit': patch
---

Add "svelte" field to package.json when running package command
