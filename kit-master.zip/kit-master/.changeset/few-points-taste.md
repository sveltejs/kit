---
'@sveltejs/kit': patch
---

Force Vite to bundle Svelte component libraries in SSR
