---
'@sveltejs/kit': patch
---

Fix regex for getting links to crawl during prerendering
