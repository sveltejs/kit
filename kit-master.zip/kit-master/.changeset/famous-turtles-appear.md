---
'@sveltejs/kit': patch
---

Add copy function to Builder.js
