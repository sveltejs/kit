---
"@sveltejs/kit": patch
---

reset selection in setTimeout after navigating, to ensure correct behaviour in Firefox
