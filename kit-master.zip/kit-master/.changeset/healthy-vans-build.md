---
'@sveltejs/kit': patch
---

[chore] upgrade node-fetch to 3.0.0 final
