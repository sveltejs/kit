---
'create-svelte': patch
---

remove session remnants
