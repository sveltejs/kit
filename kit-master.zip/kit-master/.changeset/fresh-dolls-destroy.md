---
'@sveltejs/kit': patch
---

[fix] upgrade to Vite 2.7
