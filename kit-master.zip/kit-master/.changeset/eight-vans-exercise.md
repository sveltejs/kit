---
'@sveltejs/adapter-auto': patch
---

[feat] support Azure SWA
