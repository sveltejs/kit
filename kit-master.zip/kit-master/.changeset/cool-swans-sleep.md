---
'@sveltejs/adapter-auto': patch
---

Force republish
