---
'@sveltejs/kit': patch
---

Apply define config to service worker
