---
"@sveltejs/kit": patch
---

fix rest param type generation
