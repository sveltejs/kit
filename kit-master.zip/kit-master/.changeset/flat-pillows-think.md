---
'@sveltejs/adapter-node': patch
'@sveltejs/adapter-vercel': patch
---

Fix adapter-vercel query parsing and update adapter-node's
