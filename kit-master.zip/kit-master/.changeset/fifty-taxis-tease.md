---
'create-svelte': patch
---

Add index.js file to `pkg.files`
