---
'@sveltejs/kit': patch
---

Allow index files to use named layouts
