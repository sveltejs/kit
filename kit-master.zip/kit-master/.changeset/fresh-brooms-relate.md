---
'@sveltejs/kit': patch
---

Fix server manifest generation
