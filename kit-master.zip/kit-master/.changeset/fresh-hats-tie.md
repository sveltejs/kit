---
'@sveltejs/kit': patch
---

[fix] point at true dev entry point
