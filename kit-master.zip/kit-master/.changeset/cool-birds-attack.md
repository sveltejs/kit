---
'@sveltejs/kit': patch
---

Correctly provide server parent data
