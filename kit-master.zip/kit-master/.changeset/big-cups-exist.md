---
'@sveltejs/kit': patch
---

[breaking] remove amp config option in favour of amp.transform helper function
