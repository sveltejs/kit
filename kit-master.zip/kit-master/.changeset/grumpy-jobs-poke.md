---
'@sveltejs/kit': patch
---

[breaking] add API for interacting with cookies
