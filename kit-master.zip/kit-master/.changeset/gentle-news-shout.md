---
'@sveltejs/kit': patch
---

Return a 303 response when a `POST` handler provides a `location`
