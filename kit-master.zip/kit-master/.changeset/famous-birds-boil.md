---
'svelte-migrate': patch
---

Correctly rename files with spaces when migrating
