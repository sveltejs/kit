---
'@sveltejs/kit': patch
---

Add returned stuff from pages into \$page store
