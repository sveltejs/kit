---
"@sveltejs/kit": patch
---

[fix] stop flash of unstyled content when using CSS flavours
