---
'@sveltejs/adapter-cloudflare': patch
---

use posix to resolve relative path
