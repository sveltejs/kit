---
'@sveltejs/adapter-netlify': patch
---

Use multivalue headers to set multiple cookies
