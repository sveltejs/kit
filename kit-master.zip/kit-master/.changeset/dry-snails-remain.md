---
'@sveltejs/kit': patch
---

[fix] add missing depends function to ServerLoadEvent type
