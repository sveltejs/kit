---
'@sveltejs/kit': patch
---

[chore] separate RequestHeaders and ResponseHeaders types
