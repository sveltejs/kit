---
'@sveltejs/kit': patch
---

[breaking] change sveltekit.message to sveltekit.error.message
