---
'@sveltejs/kit': patch
---

[fix] prevent text unselection for keepfocus
