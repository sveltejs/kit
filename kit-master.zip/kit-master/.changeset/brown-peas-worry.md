---
'@sveltejs/kit': patch
---

Fix AMP styles
