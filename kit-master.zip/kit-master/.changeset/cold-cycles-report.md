---
'@sveltejs/kit': patch
---

Prevent validation_errors from being serialized twice
