---
'@sveltejs/adapter-netlify': patch
---

Update adapter to only glob files
