---
'@sveltejs/kit': patch
---

Use Vite
