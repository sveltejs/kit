---
'create-svelte': patch
---

bump eslint plugin and parser in template
