---
'svelte-migrate': patch
---

Revert change to suggest props destructuring
