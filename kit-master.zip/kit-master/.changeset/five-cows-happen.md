---
"@sveltejs/kit": patch
---

fix `BodyValidator` for nested interfaces
