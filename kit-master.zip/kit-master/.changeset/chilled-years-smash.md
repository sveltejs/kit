---
"create-svelte": patch
---

make variable names more descriptive
