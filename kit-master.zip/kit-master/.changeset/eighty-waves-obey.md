---
'@sveltejs/adapter-node': patch
---

[feat] allow node adapter to configure listen path
