---
'@sveltejs/kit': patch
---

Replace regex routes with fallthrough routes
