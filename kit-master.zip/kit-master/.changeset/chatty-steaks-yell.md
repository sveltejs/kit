---
'create-svelte': patch
---

Fix preprocess option in template
