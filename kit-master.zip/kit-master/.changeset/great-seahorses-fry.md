---
'create-svelte': patch
---

fix `@typescript-eslint/no-empty-interface` lint error when starting a new app with eslint
