---
'@sveltejs/kit': patch
---

[fix] update page status when applying action
