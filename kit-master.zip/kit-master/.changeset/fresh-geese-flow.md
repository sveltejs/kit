---
'@sveltejs/adapter-node': patch
---

Update docs
