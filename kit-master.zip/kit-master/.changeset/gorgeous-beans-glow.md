---
'@sveltejs/kit': patch
---

[breaking] expose entire config to adapters, rather than just appDir and trailingSlash
