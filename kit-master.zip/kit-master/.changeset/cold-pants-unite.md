---
'create-svelte': patch
'@sveltejs/kit': patch
---

fix: adapt to svelte ids without ?import in vite 2.2.3
