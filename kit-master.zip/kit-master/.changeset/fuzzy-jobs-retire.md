---
'@sveltejs/adapter-vercel': patch
---

Use path.posix to resolve routes for esmodules
