---
'@sveltejs/kit': patch
---

add config.kit.package.emitTypes
