---
'@sveltejs/kit': patch
---

Return the copied files from the adapter's copy\_ utils.
