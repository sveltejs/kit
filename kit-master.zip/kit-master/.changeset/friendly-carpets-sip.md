---
'@sveltejs/kit': patch
---

[fix] allow overriding inlineDynamicImports
