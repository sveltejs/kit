---
'@sveltejs/kit': patch
---

[fix] safely join url segments in manifest
