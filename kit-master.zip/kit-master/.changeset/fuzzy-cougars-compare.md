---
'@sveltejs/kit': patch
---

Fix client-side redirect loop detection
