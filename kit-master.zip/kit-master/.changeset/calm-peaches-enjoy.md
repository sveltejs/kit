---
'@sveltejs/kit': patch
---

[fix] handle redirects in handle hook while processing data request
