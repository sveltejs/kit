---
'@sveltejs/adapter-netlify': patch
'@sveltejs/adapter-node': patch
'@sveltejs/adapter-static': patch
'create-svelte': patch
---

[breaking] standardize final output dir as /build (vs /.svelte-kit)
