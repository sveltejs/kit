---
'@sveltejs/kit': patch
---

Handle function without params when writing TS proxy
