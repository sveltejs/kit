---
'@sveltejs/kit': patch
---

Allow .d.ts files to have a + prefix
