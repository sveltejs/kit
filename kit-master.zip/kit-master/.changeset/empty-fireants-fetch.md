---
'@sveltejs/kit': patch
---

external fetch calls: ensure serialized cookie values are url-encoded [#7736]
