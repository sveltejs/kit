---
'@sveltejs/kit': patch
---

Tweak AMP validation screen
