---
'@sveltejs/adapter-node': patch
'@sveltejs/kit': patch
---

Add options to adapter-node, and add adapter types
