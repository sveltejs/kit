---
'@sveltejs/adapter-vercel': patch
---

Remove unused target option from config.json
