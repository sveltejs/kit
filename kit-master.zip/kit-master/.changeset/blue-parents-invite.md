---
'@sveltejs/kit': patch
---

Only fall back to full page reload if pathname has changed