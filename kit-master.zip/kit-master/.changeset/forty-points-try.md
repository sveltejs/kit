---
"@sveltejs/kit": patch
---

Updated undici to fix #5383
