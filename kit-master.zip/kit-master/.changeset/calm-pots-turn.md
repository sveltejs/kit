---
'@sveltejs/kit': patch
---

Remove startGlobal option
