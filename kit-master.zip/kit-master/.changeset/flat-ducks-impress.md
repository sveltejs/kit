---
'@sveltejs/adapter-vercel': patch
---

Fix dependencies
