---
'@sveltejs/kit': patch
---

[fix] don't de-indent user-rendered HTML
