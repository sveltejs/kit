---
'@sveltejs/kit': patch
---

Pin vite-plugin-svelte to 1.0.0-next.49
