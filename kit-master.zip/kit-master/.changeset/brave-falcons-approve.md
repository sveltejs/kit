---
'@sveltejs/kit': patch
---

update svelte peerDependency to 3.39.0
