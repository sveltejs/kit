---
'@sveltejs/kit': patch
---

Respect `export const prerender = false` in `+page.server.js`
