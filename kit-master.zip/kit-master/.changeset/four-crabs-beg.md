---
'@sveltejs/kit': patch
---

[perf] render head links before other content
