---
'@sveltejs/package': patch
---

[fix] don't strip `type="application/.."` tags
