---
"create-svelte": patch
---

type check exception handling on form action
