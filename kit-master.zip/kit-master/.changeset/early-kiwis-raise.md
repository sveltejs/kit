---
'@sveltejs/kit': patch
---

[chore] Skip removing HTTP/2 pseudo-headers, which is no longer necessary with undici
