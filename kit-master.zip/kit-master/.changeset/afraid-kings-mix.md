---
'@sveltejs/kit': patch
---

[fix] forward cookies from fetch on redirect response
