---
'create-svelte': patch
---

Fix usage of request.locals in starter project
