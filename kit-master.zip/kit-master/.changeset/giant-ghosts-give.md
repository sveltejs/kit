---
'@sveltejs/kit': patch
---

[fix] support etag W/ prefix
