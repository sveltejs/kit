---
'create-svelte': patch
---

Use crypto.randomUUID() instead of @lukeed/uuid
