---
'@sveltejs/vite-plugin-svelte': patch
---

Include index.js in package
