---
'@sveltejs/kit': patch
---

Adjust type imports to satisfy TS NodeNext moduleResolution
