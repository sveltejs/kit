---
"@sveltejs/kit": patch
---

create stronger types for dynamically generated env modules
