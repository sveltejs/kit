---
'@sveltejs/adapter-node': patch
---

Allow the environment variables containing the host and port to serve on to be customised
