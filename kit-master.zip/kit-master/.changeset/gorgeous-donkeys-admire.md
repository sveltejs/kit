---
'create-svelte': patch
'@sveltejs/kit': patch
---

Add ambient types to published files
