---
'@sveltejs/kit': patch
---

AMP support
