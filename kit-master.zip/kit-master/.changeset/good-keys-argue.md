---
'@sveltejs/adapter-netlify': patch
---

Bump version to trigger rebuild with set-cookie support
