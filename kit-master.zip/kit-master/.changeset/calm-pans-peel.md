---
'@sveltejs/kit': patch
---

Ignore dynamically imported components when constructing styles in dev mode
