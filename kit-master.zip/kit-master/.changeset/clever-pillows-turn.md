---
"@sveltejs/kit": patch
---

[chore] upgrade undici
