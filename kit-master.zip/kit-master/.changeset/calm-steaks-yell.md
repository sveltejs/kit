---
'@sveltejs/kit': patch
---

bump vite-plugin-svelte to 1.0.3 to fix an issue with svelte-inspector in vite 3.1
