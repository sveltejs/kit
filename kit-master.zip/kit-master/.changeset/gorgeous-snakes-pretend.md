---
'@sveltejs/kit': patch
---

Generate `__data.json` files for server-side redirects when prerendering
