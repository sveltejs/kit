---
'@sveltejs/kit': patch
---

[fix] optional params can be undefined
