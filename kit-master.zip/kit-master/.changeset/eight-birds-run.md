---
'@sveltejs/adapter-vercel': patch
---

Expose external option
