---
'@sveltejs/kit': patch
---

Reload page to recover from HMR errors
