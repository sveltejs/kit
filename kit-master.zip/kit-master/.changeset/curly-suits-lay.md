---
'@sveltejs/kit': patch
---

[fix] prerendering path and layout fixes
