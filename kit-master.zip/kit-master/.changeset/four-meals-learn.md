---
'create-svelte': patch
'@sveltejs/kit': patch
---

[chore] bump ts version and ensure it works with latest changes
