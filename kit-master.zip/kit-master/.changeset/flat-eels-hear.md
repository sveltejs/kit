---
'@sveltejs/kit': patch
---

[fix] upgrade minor deps. fetch-blob 3.1.3 needed for Netlify deploys
