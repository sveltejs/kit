---
'@sveltejs/kit': patch
---

Correctly identify readable node streams
