---
'create-svelte': patch
---

Fix typo in template app
