---
'create-svelte': patch
---

Show git init instructions when creating new project
