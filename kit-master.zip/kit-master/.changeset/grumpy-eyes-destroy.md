---
'@sveltejs/kit': patch
---

[fix] bump required Vite version and address warning
