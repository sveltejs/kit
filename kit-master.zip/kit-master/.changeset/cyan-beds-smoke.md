---
'@sveltejs/kit': patch
---

Don't print search params error when prerendering fallback page
