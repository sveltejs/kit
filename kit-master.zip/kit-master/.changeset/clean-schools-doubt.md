---
'@sveltejs/kit': patch
---

Make 404 error more helpful if paths.base is missing
