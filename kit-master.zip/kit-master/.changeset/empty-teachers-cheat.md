---
'@sveltejs/kit': patch
---

[breaking] Endpoint method names uppercased to match HTTP specifications
