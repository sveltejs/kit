---
'@sveltejs/kit': patch
---

Stream request bodies
