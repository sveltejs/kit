---
'@sveltejs/kit': patch
---

Fix default error page
