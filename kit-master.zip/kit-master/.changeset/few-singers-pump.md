---
'@sveltejs/adapter-node': patch
---

Convert to ESM
