---
'@sveltejs/kit': patch
---

[fix] fire navigation-end event only at end of navigation
