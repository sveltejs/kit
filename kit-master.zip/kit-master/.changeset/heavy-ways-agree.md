---
'@sveltejs/adapter-node': patch
---

Allow sirv to looks for precompiled gzip and brotli files by default
