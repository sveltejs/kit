---
'create-svelte': patch
---

Improved install prompts, turn confirms into toggle
