---
'@sveltejs/kit': patch
---

[fix] better navigation protocol check
