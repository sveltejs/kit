---
'create-svelte': patch
---

update comment to remove outdated reference
