---
'@sveltejs/kit': patch
---

Move renderer out of app assets folder
