---
'@sveltejs/kit': patch
---

Add cookies.serialize method
