---
'@sveltejs/kit': patch
---

[fix] prefetch should ignore links ignored by the router
