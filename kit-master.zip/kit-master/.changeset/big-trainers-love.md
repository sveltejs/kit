---
'@sveltejs/adapter-node': patch
---

Bundle non-production dependencies with esbuild
