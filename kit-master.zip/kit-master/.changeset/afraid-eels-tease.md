---
'@sveltejs/adapter-netlify': patch
---

[fix] adapter-netlify: handle undefined body
