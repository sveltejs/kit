---
'@sveltejs/adapter-node': patch
---

Use getRawBody
