---
'create-svelte': patch
---

[fix] remove Sverdle from Stackblitz template
