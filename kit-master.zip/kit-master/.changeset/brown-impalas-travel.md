---
'@sveltejs/kit': patch
---

Include service worker in manifest
