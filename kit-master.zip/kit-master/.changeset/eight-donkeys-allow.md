---
"@sveltejs/kit": patch
---

declare function type with named syntax
