---
'@sveltejs/kit': patch
---

Apply set-cookie headers from page dependencies
