---
'@sveltejs/adapter-netlify': patch
---

Deploy generated Netlify entrypoint to the internal functions directory. This allows it to co-exist with other Netlify functions.
