---
'@sveltejs/kit': patch
---

The path to a service worker is now rebased to the app's base path
