---
'create-svelte': patch
---

Disable type checking by default for non-typescript projects.
