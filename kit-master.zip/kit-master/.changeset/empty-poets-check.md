---
'@sveltejs/kit': patch
---

[fix] deeply-nested error components render with correct layout
