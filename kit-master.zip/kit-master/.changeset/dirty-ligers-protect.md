---
'@sveltejs/kit': patch
---

Use meta http-equiv=refresh
