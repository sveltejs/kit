---
'@sveltejs/kit': patch
---

Pass config to vite-plugin-svelte instead of reloading it
