---
'create-svelte': patch
---

Fix location of example `Counter.svelte` component
