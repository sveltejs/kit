---
'@sveltejs/kit': patch
---

Work around apparent Cloudflare Workers platform bugs
