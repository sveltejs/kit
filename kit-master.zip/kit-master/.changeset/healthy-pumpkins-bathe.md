---
'@sveltejs/kit': patch
---

Call correct set_paths function
