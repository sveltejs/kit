---
'@sveltejs/adapter-cloudflare-workers': patch
---

- Fix an issue related to prerendered pages incorrectly resolving in @sveltejs/adapter-cloudflare-workers
