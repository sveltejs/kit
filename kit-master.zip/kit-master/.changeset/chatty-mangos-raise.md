---
'@sveltejs/kit': patch
---

Always remove trailing slashes
