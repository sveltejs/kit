---
'@sveltejs/kit': patch
---

fix to ActionData type generation
