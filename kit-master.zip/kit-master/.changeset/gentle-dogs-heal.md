---
"@sveltejs/adapter-cloudflare": patch
---

Add new "adapter-cloudflare" package for Cloudflare Pages with Workers integration
